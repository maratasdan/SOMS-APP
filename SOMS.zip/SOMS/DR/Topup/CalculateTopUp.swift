//
//  CalculateTopUp.swift
//  SOMS
//
//  Created by Dan XD on 2/26/26.
//

import SwiftUI

struct CalculateTopUp: View {
    
    let dhid: String
    let noh: String
    let rhid: String
    
    var body: some View {
        Text(noh)
    }
}

#Preview {
    CalculateTopUp(dhid: "", noh: "", rhid: "")
}
