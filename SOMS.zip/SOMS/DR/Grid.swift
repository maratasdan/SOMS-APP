//
//  Grid.swift
//  SOMS
//
//  Created by Dan XD on 2/19/26.
//

import SwiftUI
import SwiftData

struct Grid: View {
    
    @Environment(\.modelContext) private var context
    @Query private var dyerheaderlist: [DryerHeader]
    
    @StateObject var timer = CountdownTimer()
    
    @State private var startDate = ""

    var body: some View {
        NavigationStack {
            VStack {

                List {
                    ForEach(dyerheaderlist) { list in
                        VStack(alignment: .leading){
                            HStack{
                                Label("\(list.binid)", systemImage: "flame.circle")
                                    .font(.title2)
                                    .tint(.red)
                                Spacer()
                                
                                NavigationLink(destination: Panel(dhid: list.dhid, startDate: list.start, rhid: list.rhid)){
                                    Label("", systemImage: "")
                                }
                                Text(list.start)
                            }
                            
                            Spacer()
                            Spacer()
                            
                            HStack{
                                Label("\(list.lot_no)", systemImage: "widget.small")
                                    .font(.caption)
                                Spacer()
                                Label("\(list.rhid)", systemImage: "tag")
                                    .font(.caption)
                                Spacer()
                                Label("\(list.dhid)", systemImage: "")
                                    .font(.caption)
                            }
                            
                            Spacer()
                            Spacer()
                            
//                            HStack{
//                                Text(timer.timeString())
//                                                .font(.system(size: 40, weight: .bold, design: .monospaced))
//                                Spacer()
//                                Button("Start 1 Hour Countdown") {
//                                                timer.start(hours: 1)
//                                            }
                            }
                            
                        }
                        
                    }
                }
            }
            .navigationTitle("Drying List")
            .onAppear {
                print("Fetched count:", dyerheaderlist.count)
            }
        
    }

    func deleteAll() {
        
        for item in dyerheaderlist {
            context.delete(item)
        }
        do {
            try context.save()
            print("Deleted all DryerHeader")
        } catch {
            print("Delete error:", error)
        }
        
    }
}


#Preview {
    Grid()
}
