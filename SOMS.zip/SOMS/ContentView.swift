//
//  ContentView.swift
//  SOMS
//
//  Created by Dan XD on 2/19/26.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    var body: some View {
        NavigationStack {
            VStack{
                
            }
            VStack {
                List {
                    Section(header: Text("DRYING")){
                        HStack {
                            Label("DRYING PANEL", systemImage: "flame.fill")
                            NavigationLink(destination: Grid()) {
                                
                            }
                        }
                        HStack {
                            Label("CONFIRM", systemImage: "circle.badge.checkmark")
                            NavigationLink(destination: Confirm()) {
                                
                            }
                        }
                        HStack {
                            Label("TOPUP", systemImage: "square.and.arrow.down")
                            NavigationLink(destination: Topup()) {
                                
                            }
                        }
                    }
                   
                }
            }
        }
        .navigationTitle("Home")
    }
}

#Preview {
    ContentView()
}
